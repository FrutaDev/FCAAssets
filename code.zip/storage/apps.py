from django.apps import AppConfig


class StorageConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'storage'


    def ready(self):
        from .email_apscheduler import start_scheduler
        start_scheduler()
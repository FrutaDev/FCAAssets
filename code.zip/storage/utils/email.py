from django.core.mail import EmailMessage
from django.template.loader import render_to_string
from django.conf import settings
from django.db import transaction
from datetime import date

def send_maintenance_email(maintenance, days_before):

    if days_before == 30:
        kind = "30_days"
    elif days_before == 7:
        kind = "7_days"
    else:
        kind = "due"

    return __send_email_for(maintenance, kind)


def __send_email_for(maintenance, kind):

    if kind == '30_days':
        subject = f'Recordatorio: Mantenimiento para {maintenance.machinary_maintenance.serial} en 30 días'
        template = 'emails/maintenance_30_days.html'
        flag_field = 'email_sent_30_days'

    elif kind == '7_days':
        subject = f'Recordatorio: Mantenimiento para {maintenance.machinary_maintenance.serial} en 7 días'
        template = 'emails/maintenance_7_days.html'
        flag_field = 'email_sent_7_days'

    else:
        subject = f'Notificación: Mantenimiento para {maintenance.machinary_maintenance.serial} es hoy'
        template = 'emails/maintenance_due.html'
        flag_field = 'email_sent_due'

    context = {
        'maintenance': maintenance,
        'machinery': maintenance.machinary_maintenance,
        'days_remaining': (maintenance.maintenance_date - date.today()).days,
    }

    body = render_to_string(template, context)
    recipient_list = settings.MAINTENANCE_NOTIFICATION_ADMINS

    with transaction.atomic():
        msg = EmailMessage(
            subject=subject,
            body=body,
            to=recipient_list,
        )
        msg.content_subtype = "html"
        msg.send(fail_silently=False)

        setattr(maintenance, flag_field, True)
        maintenance.save(update_fields=[flag_field])

from apscheduler.schedulers.background import BackgroundScheduler
from django.utils import timezone
from datetime import timedelta
from .models import Maintenance
from .utils.email import send_maintenance_email
import logging
from django.db import transaction

logger = logging.getLogger("maintenance_scheduler")

def job_send_maintenance_emails():
    today = timezone.now().date()

    jobs = [
        (30, "email_sent_30_days"),
        (7,  "email_sent_7_days"),
        (0,  "email_sent_due"),
    ]

    for days, flag in jobs:
        records = Maintenance.objects.filter(
            maintenance_date=today + timedelta(days=days),
            **{flag: False}
        )

        for m in records:
            try:
                send_maintenance_email(m, days)
                logger.info(f"Email enviado ({days} días) para ID={m.pk}")
            except Exception:
                logger.exception(f"Error enviando correo ({days} días) para ID={m.pk}")


def start_scheduler():
    scheduler = BackgroundScheduler()
    scheduler.add_job(
        job_send_maintenance_emails,
        trigger="cron",
        hour=8,
        minute=0,
    )
    scheduler.start()
